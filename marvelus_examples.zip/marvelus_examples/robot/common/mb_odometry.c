/*******************************************************************************
* mb_odometry.c
*
* TODO: Implement these functions to add odometry and dead reckoning 
*
*******************************************************************************/

#include "../mobilebot/mobilebot.h"
#include "mb_defs.h"
#include "mb_odometry.h"
#include <math.h>

#define PI 3.14159265358979323846
float transverse_correction = 1.0;
float angle_correction = 1.0;

/*******************************************************************************
* mb_initialize_odometry() 
*
* TODO: initialize odometry
*
*******************************************************************************/
int mb_initialize_odometry(mb_odometry_t* mb_odometry, float x, float y, float theta){
    if(mb_load_odometry_config(ODO_CFG_PATH)){
        return -1;
    }
    mb_odometry->x = x;
    mb_odometry->y = y;
    mb_odometry->theta = theta;
    return 0;
}


int mb_load_odometry_config(char *cfg_path){
    FILE* file = fopen(cfg_path, "r");
    if (file == NULL){
        printf("Error opening %s\n", cfg_path);
        return -1;
    }
    fscanf(file, "%f", &thresh_gyrodometry);
    fscanf(file, "%f", &transverse_correction);
    fscanf(file, "%f", &angle_correction);

    // convert to radians
    thresh_gyrodometry = thresh_gyrodometry * PI/180;
    return 0;
}

/*******************************************************************************
* mb_update_odometry() 
*
* TODO: calculate odometry from internal variables
*       publish new odometry to lcm ODOMETRY_CHANNEL
*
*******************************************************************************/
void mb_update_odometry(mb_odometry_t* mb_odometry, mb_state_t* mb_state){
    // All this is from encoders
    float deltasl = ENC2METERS*mb_state->left_encoder_delta;
    float deltasr = ENC2METERS*mb_state->right_encoder_delta;
    float deltatheta_odo = (deltasr - deltasl)/WHEEL_BASE;
    float deltad = (deltasr + deltasl)/2 * transverse_correction;

    // This is from the gyro
    float deltatheta_mpu = mb_state->tb_angles[2]-mb_state->last_yaw;

    // Angle delta between gyro and odometry
    float delta_go = fabs(deltatheta_mpu - deltatheta_odo);

    float deltatheta;
    if(delta_go > thresh_gyrodometry){
        deltatheta = deltatheta_mpu;
    }
    else{
        deltatheta = deltatheta_odo;
    }
    deltatheta *= angle_correction;
    mb_odometry->x += deltad*cos(mb_odometry->theta + 0.5*deltatheta);
    mb_odometry->y += deltad*sin(mb_odometry->theta + 0.5*deltatheta);
    mb_odometry->theta = mb_clamp_radians(mb_odometry->theta + deltatheta);
    mb_odometry->odo_disagree = delta_go;
}


/*******************************************************************************
* mb_clamp_radians() 
* clamp an angle from -PI to PI
*******************************************************************************/
float mb_clamp_radians(float angle){

    if(angle < -PI)
    {
        for(; angle < -PI; angle += 2.0*PI);
    }
    else if(angle > PI)
    {
        for(; angle > PI; angle -= 2.0*PI);
    }

    return angle;
}


/*******************************************************************************
* mb_angle_diff_radians() 
* computes difference between 2 angles and wraps from -PI to PI
*******************************************************************************/
float mb_angle_diff_radians(float angle1, float angle2){
    float diff = angle2 - angle1;
    while(diff < -PI) diff+=2.0*PI;
    while(diff > PI) diff-=2.0*PI;
    return diff;
}