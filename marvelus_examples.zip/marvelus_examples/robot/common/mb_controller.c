#include "../mobilebot/mobilebot.h"
#include "mb_controller.h"

/*******************************************************************************
* int mb_initialize()
*
* this initializes all the PID controllers from the configuration file
* you can use this as is or modify it if you want a different format
*
* return 0 on success
*
*******************************************************************************/

int mb_initialize_controller(){
    // Load left pid config
    
    // Catch errors
    if(mb_load_controller_config(PID_CFG_PATH)){
        return -1;
    }
    // Initialize left wheel PID
    left_wheel_speed_pid = rc_filter_empty();
    rc_filter_pid(
        &left_wheel_speed_pid, 
        left_pid_params.kp, 
        left_pid_params.ki, 
        left_pid_params.kd, 
        left_pid_params.dFilterHz, DT);

    // Initialize right wheel PID
    right_wheel_speed_pid = rc_filter_empty();
    rc_filter_pid(
        &right_wheel_speed_pid, 
        right_pid_params.kp, 
        right_pid_params.ki, 
        right_pid_params.kd, 
        right_pid_params.dFilterHz, DT);

    transverse_filter = rc_filter_empty();
    rc_filter_first_order_lowpass(&transverse_filter, DT, 1/transverse_filter_freq);

    return 0;
}

/*******************************************************************************
* int mb_load_controller_config()
*
* this provides a basic configuration load routine
* you can use this as is or modify it if you want a different format
*
* return 0 on success
*
*******************************************************************************/


int mb_load_controller_config(char *cfg_path){
    FILE* file = fopen(cfg_path, "r");
    if (file == NULL){
        printf("Error opening %s\n", cfg_path);
        return -1;
    }
    fscanf(file, "%f %f %f %f", 
        &right_pid_params.kp,
        &right_pid_params.ki,
        &right_pid_params.kd,
        &right_pid_params.dFilterHz
        );

    fscanf(file, "%f %f %f",
        &right_feed_forward_slope,
        &right_feed_forward_intercept,
        &right_feed_forward_mix);

    fscanf(file, "%f %f %f %f", 
        &left_pid_params.kp,
        &left_pid_params.ki,
        &left_pid_params.kd,
        &left_pid_params.dFilterHz
        );

    fscanf(file, "%f %f %f",
        &left_feed_forward_slope,
        &left_feed_forward_intercept,
        &left_feed_forward_mix);

    fscanf(file, "%f", &transverse_filter_freq);

/******
*
*   Example of loading a line from .cfg file:
*
*    fscanf(file, "%f %f %f %f", 
*        &pid_params.kp,
*        &pid_params.ki,
*        &pid_params.kd,
*        &pid_params.dFilterHz
*        );
*
******/

    fclose(file);
    return 0;
}

/*******************************************************************************
* int mb_controller_update()
* 
* TODO: Write your PID controller here
* take inputs from the global mb_state
* write outputs to the global mb_state
*
* return 0 on success
*
*******************************************************************************/

int mb_controller_update(mb_state_t* mb_state, mb_setpoints_t* mb_setpoints){  
    // Figure out setpoints per motor
    // We define positive turn velocity as turning left and negative as right
    float left_setpoint = rc_filter_march(&transverse_filter, mb_setpoints->fwd_velocity) - (mb_setpoints->turn_velocity*(WHEEL_BASE));
    float right_setpoint = rc_filter_march(&transverse_filter, mb_setpoints->fwd_velocity) + (mb_setpoints->turn_velocity*(WHEEL_BASE));
    
    // Update PID
    float left_pid_out = rc_filter_march(&right_wheel_speed_pid, left_setpoint-mb_state->left_velocity);
    float right_pid_out = rc_filter_march(&left_wheel_speed_pid, right_setpoint-mb_state->right_velocity);

    // Add feed-forward term
    float left_sum_out = (left_feed_forward_mix*left_setpoint) + left_pid_out;
    float right_sum_out = (right_feed_forward_mix*right_setpoint) + right_pid_out;

    float left_pwm_out = 0.0;
    float right_pwm_out = 0.0;
    
    // Convert to PWM values
    if (mb_setpoints->fwd_velocity == 0) {
        left_pwm_out = (left_sum_out)/left_feed_forward_slope;
        right_pwm_out = (right_sum_out)/right_feed_forward_slope;
    } else {
        left_pwm_out = (left_sum_out + left_feed_forward_intercept*(left_setpoint>0?-1:1))/left_feed_forward_slope;
        right_pwm_out = (right_sum_out + right_feed_forward_intercept*(right_setpoint>0?-1:1))/right_feed_forward_slope;
    }
    

    // Keep them within range
    rc_saturate_float(&left_pwm_out, -1, 1);
    rc_saturate_float(&right_pwm_out, -1, 1);

    // Update the motor commands
    mb_state->left_cmd = left_pwm_out;
    mb_state->right_cmd = right_pwm_out;
    return 0;
}

/*******************************************************************************
* int mb_destroy_controller()
* 
* TODO: Free all resources associated with your controller
*
* return 0 on success
*
*******************************************************************************/

int mb_destroy_controller(){
    // Free up PID filters
    rc_filter_free(&left_wheel_speed_pid);
    rc_filter_free(&right_wheel_speed_pid);
    return 0;
}
