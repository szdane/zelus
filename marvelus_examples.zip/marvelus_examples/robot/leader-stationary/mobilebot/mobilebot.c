/*******************************************************************************
*    mobilebot.c
*    Template Code
*    
*    This code is a template for completing a fully featured
*    mobile robot controller
*   
*    Functions that need completing are marked with "TODO:"
* 
*******************************************************************************/
#include "mobilebot.h"
#define PI 3.14159265358979323846

/*******************************************************************************
* int main() 
*
*******************************************************************************/

// Sets the starting position of the robot
#define DIST_INITIAL 5.0

int main(){
    
	is_ready = 0;
	
    rc_led_set(RC_LED_GREEN, LED_OFF);
    rc_led_set(RC_LED_RED, LED_ON);
	//set cpu freq to max performance
	rc_cpu_set_governor(RC_GOV_PERFORMANCE); // sets cpu to fastest speed 0 on success, -1 on failure
    // start signal handler so we can exit cleanly
    if(rc_enable_signal_handler()==-1){
        fprintf(stderr,"ERROR: failed to start signal handler\n");
        return -1;
    }

    // setpoint_filter = rc_filter_empty();
    // rc_filter_moving_average(&setpoint_filter, 2, DT);

	// start lcm handle thread
	printf("starting lcm thread... \n");
	lcm = lcm_create(LCM_ADDRESS); //. inputs const char* returns a newly allocated lcm_t instance or NULL on failure free with lcm_destroy() when no longer needed 
	pthread_t lcm_subscribe_thread; //. pthread_t abstract type is implemented as an integer (4 byte) thread ID
    rc_pthread_create(&lcm_subscribe_thread, lcm_subscribe_loop, (void*) NULL, SCHED_FIFO, LCM_PRIORITY); //. &lcm_sbscribe_thread gives the 4 byte address
    //. is a function starts a new thread in the calling process. the new thread starts execution by invoking start_routine()
    //. on success it return 0 and on error in returns an error number 


	// start control thread
	printf("starting dsm_radio thread... \n");
	pthread_t  dsm_radio_thread;
	rc_pthread_create(&dsm_radio_thread, dsm_radio_control_loop, (void*) NULL, SCHED_OTHER, 0);

    // start printf_thread 
    printf("starting print thread... \n");
    pthread_t  printf_thread;
    rc_pthread_create(&printf_thread, printf_loop, (void*) NULL, SCHED_OTHER, 0);
    
    //wait for threads to set up
    //. void rc_nanosleep (uint64_t ns) sleep in nanoseconds 1E5 = 485 nano second
    rc_nanosleep(1E5);


	// set up IMU configuration
    // see RCL documentation for other parameters
    //.An IMU (Inertial Measurement Unit) is a sensor that measures force, angular rate and direction using an accelerometer, gyroscope and magnetometer.
	printf("initializing imu... \n");
     rc_mpu_config_t imu_config = rc_mpu_default_config( );   //Returns an rc_mpu_config_t struct with default settings.
    //. dmp setting only used with DMP mode (digital motion processor)
	imu_config.dmp_sample_rate = SAMPLE_RATE_HZ;  //. int 
    imu_config.dmp_fetch_accel_gyro=1;              //. set to 1 to optionaly raw accel/gyro when reading DMP quaternion defalut: 0 (off)
    imu_config.dmp_interrupt_sched_policy = SCHED_FIFO; // int
    imu_config.dmp_interrupt_priority = CONTROLLER_PRIORITY;
    
    //. rc_mpu_initialize_dmp 0 in success -1 in failer
	if(rc_mpu_initialize_dmp(&imu_data, imu_config)){
		fprintf(stderr,"ERROR: can't talk to IMU! Exiting.\n");
		return -1;
	}

	//initialize state mutex
    //. A mutex is a lockable object that is designed to signal when critical sections of code need exclusive access
    pthread_mutex_init(&state_mutex, NULL);

	//attach controller function to IMU interrupt
	printf("initializing controller...\n");
    if(mb_initialize_controller()){
        fprintf(stderr, "ERROR: can't initialize controller! Exiting.\n");
        return -1;
    }

	printf("initializing motors...\n");
#if defined(MRC_VERSION_1v3) || defined(MRC_VERSION_2v1)
   

	mb_motor_init();
    mb_motor_brake(1);
    mb_motor_set(1,0);
    mb_motor_set(2,0);
#endif

#if defined(BEAGLEBONE_BLUE)
    //. just like rc_motor_init but allows the user to set the pwm frequency.
    //. RC_MOTOR_DEFAULT_PWM_FREQ is a good frequency to start at.

    rc_motor_init_freq(DEFAULT_PWM_FREQ);
    rc_motor_standby(0);  // 0 to disable and 1 to enable standby
    rc_motor_set(1,0);      // Sets the bidirectional duty cycle (power) to a single motor or all motors if 0 is provided as a channel.
    //     Parameters
    // [in]ch	The motor channel (1-4) or 0 for all channels.
    // [in]duty	Duty cycle, -1.0 for full reverse, 1.0 for full forward
    rc_motor_set(2,0);
#endif

     //. Odometry is the use of motion sensors to determine the robot's change in position relative to some known position
     //. one way robots have of determining their position in their environment is odometry
	printf("initializing odometry...\n");
    rc_encoder_eqep_init();
    rc_encoder_eqep_write(1, 0);
    rc_encoder_eqep_write(2, 0);
    if(mb_initialize_odometry(&mb_odometry, 0.0,0.0,0.0)){
        fprintf(stderr, "ERROR: Unable to initialize odometry! Exiting.\n");
        return -1;
    }

	printf("attaching imu interupt...\n");
	rc_mpu_set_dmp_callback(&mobilebot_controller);
	printf("Waiting for the go signal...\n");
	// done initializing so set state to RUNNING
    // enum rc_state_t
    //.     Enumerator
    //. //UNINITIALIZED 	
    //. RUNNING 	
    //. PAUSED 	
    //. EXITING 

	//rc_set_state(RUNNING); 
	// Keep sending the ready signal while we wait for the go signal
	while(rc_get_state() != RUNNING && rc_get_state() != EXITING){
		ready_t ready_msg;
		ready_msg.utime = now;
		ready_t_publish(lcm, MOBILEBOT_READY_CHANNEL, &ready_msg);
		rc_nanosleep(1E8);
	}
	if(rc_get_state() != EXITING){
		printf("We are running now!\n");
    		rc_led_set(RC_LED_RED, LED_OFF);   //enum rc_led_t  RC_LED_GREEN RC_LED_RED  RC_LED_WIFI RC_LED_USR0    LED_Off is an integer 0 for off non zero fro ON
	}
	// Keep looping until state changes to EXITING
	while(rc_get_state()!=EXITING){
	// other functions are handled in other threads
	// there is no need to do anything here but sleep
        led_heartbeat();
        rc_nanosleep(7E8);
	}
	rc_led_set(RC_LED_RED, LED_ON);
	// exit cleanly
    //. int rc_pthread_timed_join	(	pthread_t 	thread,void ** 	retval,float 	timeout_sec )	
    rc_pthread_timed_join(lcm_subscribe_thread, NULL, 1.5); 
    rc_pthread_timed_join(printf_thread, NULL, 1.5);
    rc_pthread_timed_join(dsm_radio_thread, NULL, 1.5);
    rc_led_set(RC_LED_GREEN, LED_OFF);
    rc_led_set(RC_LED_RED, LED_OFF);
    //  Puts all 4 motors into a free-spin (0 throttle) state, puts the h-bridges into standby mode, and closes all file pointers to GPIO and PWM systems.
    rc_mpu_power_off();
#if defined(MRC_VERSION_1v3) || defined(MRC_VERSION_2v1)
    mb_motor_cleanup();
#endif
#if defined(BEAGLEBONE_BLUE)
    rc_motor_cleanup();
#endif
    rc_encoder_eqep_cleanup();
    mb_destroy_controller();
    rc_remove_pid_file();
	return 0;
}

/*******************************************************************************
* void read_mb_sensors()
*
* Reads all the sensors on the mobilebot
* TODO: modify this function to read other sensors
* 
*******************************************************************************/
void read_mb_sensors(){
    pthread_mutex_lock(&state_mutex); 
    // Read IMU
    mb_state.tb_angles[0] = imu_data.dmp_TaitBryan[TB_PITCH_X];
    mb_state.tb_angles[1] = imu_data.dmp_TaitBryan[TB_ROLL_Y];
    mb_state.last_yaw = mb_state.tb_angles[2];
    mb_state.tb_angles[2] = imu_data.dmp_TaitBryan[TB_YAW_Z];
    mb_state.temp = imu_data.temp;
    
    int i;
    for(i=0;i<3;i++){
        mb_state.accel[i] = imu_data.accel[i];
        mb_state.gyro[i] = imu_data.gyro[i];   //. A gyroscope is an instrument, consisting of a wheel mounted 
                                                //. into two or three gimbals providing pivoted supports, for allowing the wheel to rotate about a single axis
        mb_state.mag[i] = imu_data.mag[i];
    }

    // Read encoders    
    mb_state.left_encoder_delta = rc_encoder_eqep_read(LEFT_MOTOR)*POL_LEFT_ENCODER;
    mb_state.right_encoder_delta = rc_encoder_eqep_read(RIGHT_MOTOR)*POL_RIGHT_ENCODER;
    mb_state.left_encoder_total += mb_state.left_encoder_delta;
    mb_state.right_encoder_total += mb_state.right_encoder_delta;
    rc_encoder_eqep_write(LEFT_MOTOR,0);
    rc_encoder_eqep_write(RIGHT_MOTOR,0);

    // Calculate valocities
    mb_state.left_velocity = (mb_state.left_encoder_delta/DT)*ENC2METERS;
    mb_state.right_velocity = (mb_state.right_encoder_delta/DT)*ENC2METERS;

    //unlock state mutex
    pthread_mutex_unlock(&state_mutex);

}
/*******************************************************************************
* void publish_mb_msgs()
*
* publishes LCM messages from the mobilbot code
* TODO: modify this function to add other messages
* 
*******************************************************************************/
void publish_mb_msgs(){
/*    mbot_imu_t imu_msg;
    mbot_encoder_t encoder_msg;
    odometry_t odo_msg;

    //Create IMU LCM Message
    imu_msg.utime = now;
    imu_msg.temp = mb_state.temp;
    int i;
    for(i=0;i<3;i++){
        imu_msg.tb_angles[i] = mb_state.tb_angles[i];
        imu_msg.accel[i] = mb_state.accel[i];
        imu_msg.gyro[i] = mb_state.gyro[i];
    }

    //Create Encoder LCM message
    encoder_msg.utime = now;
    encoder_msg.left_delta = mb_state.left_encoder_delta;
    encoder_msg.right_delta = mb_state.right_encoder_delta;
    encoder_msg.leftticks = mb_state.left_encoder_total;
    encoder_msg.rightticks = mb_state.right_encoder_total;

    //TODO: Create Odometry LCM message
    odo_msg.utime = now;
    odo_msg.x = mb_odometry.x;
    odo_msg.y = mb_odometry.y;
    odo_msg.theta = mb_odometry.theta;

    //publish IMU & Encoder Data to LCM
    mbot_imu_t_publish(lcm, MBOT_IMU_CHANNEL, &imu_msg);
    mbot_encoder_t_publish(lcm, MBOT_ENCODER_CHANNEL, &encoder_msg);
    odometry_t_publish(lcm, ODOMETRY_CHANNEL, &odo_msg);
    */
}

/*******************************************************************************
* void mobilebot_controller()
*
* discrete-time mobile controller operated off IMU interrupt
* Called at SAMPLE_RATE_HZ
*
* TODO: You must add to this function so it:
*           1. calculates odometry
*           2. calculates controller ouputs
*           3. outputs commands to the motor drivers
* 
*
*******************************************************************************/
void mobilebot_controller(){
    update_now();
    read_mb_sensors();
    publish_mb_msgs();
    mb_update_odometry(&mb_odometry, &mb_state);

    // TODO: send LCM message

   if(rc_get_state() == RUNNING){ 
    lcm_t * lcm2 = lcm_create(LCM_ADDRESS);  //. Allocates and initializes a lcm_t.
    //. LCM_ADDR must be either NULL, or a string of the form "provider://network? option1 = value1 ... & optionN = valueN"
	
	robot_store_t sensor_vals;

    sensor_vals.utime = now;
    sensor_vals.command = "leader_x";
    sensor_vals.value = hypot(mb_odometry.x, mb_odometry.y) + DIST_INITIAL;
    robot_store_t_publish(lcm2, SEND_CHANNEL, &sensor_vals);

	// Just send the same thing but on a different channel with a different name
    sensor_vals.command = "sensor_dist";
    robot_store_t_publish(lcm2, DIST_SENSOR_STORE_CHANNEL, &sensor_vals); 

    sensor_vals.command = "sensor_vel";
    sensor_vals.value = 0.5 * (mb_state.left_velocity + mb_state.right_velocity);
    robot_store_t_publish(lcm2, DIST_SENSOR_STORE_CHANNEL, &sensor_vals); 

    lcm_destroy(lcm2);   //. destructor
    }

    mb_controller_update(&mb_state, &mb_setpoints);

    rc_motor_set(LEFT_MOTOR, mb_state.left_cmd*POL_LEFT_MOTOR);
    rc_motor_set(RIGHT_MOTOR, mb_state.right_cmd*POL_RIGHT_MOTOR);

}


/*******************************************************************************
*  update_now()
*
*  updates the now global variable with the current time
*
*******************************************************************************/
void update_now(){
	now = rc_nanos_since_epoch()/1000 + time_offset;
}


/*******************************************************************************
*  timesync_handler()
*
*  set time_offset based of difference 
*  between the Pi time and the local time
*
*******************************************************************************/
void timesync_handler(const lcm_recv_buf_t * rbuf, const char *channel,
				const timestamp_t *timestamp, void *_user){

	if(!time_offset_initialized) time_offset_initialized = 1;
	time_offset = timestamp->utime - rc_nanos_since_epoch()/1000;
    timestamp_t t_out;
    t_out.utime = rc_nanos_since_epoch()/1000;
    timestamp_t_publish(lcm, MBOT_TIMESYNC_CHANNEL, &t_out);
}


/*******************************************************************************
*  motor_command_handler()
*
* sets motor velocity setpoints from incoming lcm message
*
*******************************************************************************/
void motor_command_handler(const lcm_recv_buf_t *rbuf, const char *channel,
                          const mbot_motor_command_t *msg, void *user){
	// mb_setpoints.fwd_velocity = rc_filter_march(&setpoint_filter, msg->trans_v);
	// mb_setpoints.turn_velocity = rc_filter_march(&setpoint_filter, msg->angular_v);
    mb_setpoints.fwd_velocity = msg->trans_v;
    mb_setpoints.turn_velocity = msg->angular_v;

}


/*******************************************************************************
*  reset_odometry_handler()
*
* sets the initial odometry position
*
*******************************************************************************/
void reset_odometry_handler(const lcm_recv_buf_t *rbuf, const char *channel,
                          const reset_odometry_t *msg, void *user){
    mb_odometry.x = msg->x;
    mb_odometry.y = msg->y;
    mb_odometry.theta = msg->theta;
}

/*******************************************************************************
*  dsm_radio_control_loop()
*
*  sets current setpoints based on dsm radio data, odometry
*K
*  TODO: Use this thread to handle changing setpoints to your controller
*
*******************************************************************************/
void* dsm_radio_control_loop(void* ptr){

	// start dsm listener for radio control
	rc_dsm_init();

	while(1){
		if (rc_dsm_is_new_data()) {
	 		
			// TODO: Handle the DSM data from the Spektrum radio reciever
			// You may also implement switching between manual and autonomous mode
			// using channel 5 of the DSM data.

		    if(rc_dsm_ch_normalized(5) > 0.0){
			    mb_setpoints.manual_ctl = 1;
			    mb_setpoints.fwd_velocity = rc_dsm_ch_normalized(3);
			    mb_setpoints.turn_velocity = rc_dsm_ch_normalized(2);
		    }

		    else{
			    mb_setpoints.manual_ctl = 0;
		    }

	 	}
	 	rc_nanosleep(1E9 / RC_CTL_HZ);
	}
}

void robot_store_handler(const lcm_recv_buf_t /*struct*/ *rbuf, const char *channel,
                        const robot_store_t *msg, void *user){  
     //. The void pointer in C is a pointer which is not associated with any data types.
        insert_to_table(msg->command, msg->value);
//	printf("RECEIVED!\n");
    //. the strcmp() compares two strings character by character. If the strings are equal, the function returns 0.
        if(strcmp(msg->command, "transverse_vel") == 0){  // strcmp compares string
            mb_setpoints.fwd_velocity = msg->value;
        }

        if (strcmp(msg->command, "angular_vel") == 0){
            mb_setpoints.turn_velocity = msg->value;
        }
}
// Starts mobilebot when we receive the "go" signal from the launcher
void launchscript_ready_handler(const lcm_recv_buf_t *rbuf, const char *channel,
						const ready_t *msg, void *user){
		// Only need to toggle state once
		if(!is_ready){
				is_ready = 1;
				rc_set_state(RUNNING);
		}
}
/*******************************************************************************
* lcm_subscribe_loop() 
*
* thread subscribes to lcm channels and sets handler functions
* then handles lcm messages in a non-blocking fashion
*
* TODO: Add other subscriptions as needed
*******************************************************************************/
void *lcm_subscribe_loop(void *data){
    // pass in lcm object instance, channel from which to read from
    // function to call when data receiver over the channel,
    // and the lcm instance again?
    /*mbot_motor_command_t_subscribe(lcm, 
    							   MBOT_MOTOR_COMMAND_CHANNEL, 
    							   motor_command_handler, 
    							   NULL);

	timestamp_t_subscribe(lcm, 
						  MBOT_TIMESYNC_CHANNEL, 
						  timesync_handler, 
						  NULL);

    reset_odometry_t_subscribe(lcm, 
                          RESET_ODOMETRY_CHANNEL, 
                          reset_odometry_handler, 
                          NULL);*/
    robot_store_t_subscribe(lcm,
                          LISTEN_KINEMATIC_CHANNEL,
                          robot_store_handler,
                          NULL);

	// Listens for the "go" signal from the launcher
	ready_t_subscribe(lcm, SUPER_READY_CHANNEL, launchscript_ready_handler, NULL);

    while(1){
        // define a timeout (for erroring out) and the delay time
        lcm_handle_timeout(lcm, 1);
        rc_nanosleep(1E9 / LCM_HZ);
    }
    lcm_destroy(lcm);
    return 0;
}

/*******************************************************************************
* printf_loop() 
*
* prints diagnostics to console
* this only gets started if executing from terminal
*
* TODO: Add other data to help you tune/debug your code
*******************************************************************************/
void* printf_loop(void* ptr){
	rc_state_t last_state, new_state; // keep track of last state
    // FILE* log_file = fopen("log_file.txt", "w");
	while(rc_get_state()!=EXITING){
		new_state = rc_get_state();
		// check if this is the first time since being paused
		if(new_state==RUNNING && last_state!=RUNNING){
			printf("time,	acc_x,	acc_y,	acc_z,	imu_theta,	enc_l,	enc_r,	odom_x,	odom_y,	odom_theta,	set_v,	set_omega,	wheel_v_l, 	wheel_v_r\n");
		}
		else if(new_state==PAUSED && last_state!=PAUSED){
			printf("\nPAUSED\n");
		}
		last_state = new_state;
		
		if(new_state == RUNNING){
			printf("%7lld,\t", now);							// Current time
			printf("%7.3f,\t", mb_state.accel[0]);				// Accelerometer X
			printf("%7.3f,\t", mb_state.accel[1]);				// Accelerometer Y
			printf("%7.3f,\t", mb_state.accel[2]);				// Accelerometer Z
			printf("%7.3f,\t", mb_state.tb_angles[2]*180/PI);	// IMU Theta
			printf("%7lld,\t", mb_state.left_encoder_total);	// Left wheel encoder count
			printf("%7lld,\t", mb_state.right_encoder_total);	// Right wheel encoder count
			printf("%7.3f,\t", mb_odometry.x);					// Estimated X position
			printf("%7.3f,\t", mb_odometry.y);					// Estimated Y position
			printf("%7.3f,\t", mb_odometry.theta*180/PI);		// Estimated Theta
			printf("%7.3f,\t", mb_setpoints.fwd_velocity);		// Forward velocity setpoint
            printf("%7.3f,\t", mb_setpoints.turn_velocity);		// Turn velocity setpoint
            printf("%7.3f,\t", mb_state.left_velocity);			// Left wheel velocity
            printf("%7.3f", mb_state.right_velocity);			// Right wheel velocity
			printf("\n");
			fflush(stdout);

		}
		rc_nanosleep(1E9 / PRINTF_HZ);
	}
    // fclose(log_file);
	return NULL;
} 


void led_heartbeat(){
        rc_led_set(RC_LED_GREEN, LED_ON);
        rc_nanosleep(1E8);
        rc_led_set(RC_LED_GREEN, LED_OFF);
        rc_nanosleep(1E8);
        rc_led_set(RC_LED_GREEN, LED_ON);
        rc_nanosleep(1E8);
        rc_led_set(RC_LED_GREEN, LED_OFF);

}
