import time
import lcm
import ready_t
import subprocess
import threading
import signal
import sys

LABEL_WAIT = "\033[41mWAIT\033[0m"
LABEL_READY = "\033[42mREADY\033[0m"
class ReadySignalListener(threading.Thread):
    def __init__(self):
        self.lc = lcm.LCM()
        self.ready = {}
        self.listen_subscriptions = {}
        self.lock = threading.Lock()
        threading.Thread.__init__(self)
    
    def subscribe(self, channel):
        self.listen_subscriptions[channel] = self.lc.subscribe(channel, self.on_ready)
        self.ready[channel] = False
    def on_ready(self, channel, msg):
        with self.lock:
            self.ready[channel] = True

    def is_ready(self, channel):
        with self.lock:
            return self.ready[channel]

    def run(self):
        self.running = True
        while self.running:
            self.lc.handle()
            time.sleep(0.1)

    def stop(self):
        for s in self.listen_subscriptions.values():
            self.lc.unsubscribe(s)
        self.running = False     


def sendReadySignal():
    msg = ready_t.ready_t()
    msg.utime = int(time.time()*1000)
    lc.publish("SUPER_READY", msg.encode())

def on_quit(sig, frame):
    print("Caught CTRL-C")
    cleanup()
    sys.exit(0)

def cleanup():
    print("Stopping threads...")
    try:
        ready_signal_listener.stop()
    except:
        pass
    print("Stopped ready signal listener")
    p1.send_signal(signal.SIGINT)
    p2.send_signal(signal.SIGINT)
    p3.send_signal(signal.SIGINT)
    p4.send_signal(signal.SIGINT)
    p5.send_signal(signal.SIGINT)

    p1.wait()
    print("p1 stopped")
    p2.wait()
    print("p2 stopped")
    p3.wait()
    print("p3 stopped")
    p4.wait()
    print("p4 stopped")
    p5.wait()
    print("p5 stopped")

signal.signal(signal.SIGINT, on_quit)
print("Starting...")
if len(sys.argv) == 2:
    filename_suffix = "-{}".format(sys.argv[1])
else:
    filename_suffix = ""

filename_suffix += "-{}".format(int(time.time()))
channels = []

LEADER_HOSTNAME='debian@192.168.9.2'
FOLLOWER_HOSTNAME='debian@192.168.9.3'
#Leader processes
with open("leader-mobilebot{}.log".format(filename_suffix), "w") as logfile1:
    with open("leader-mobilebot{}.err".format(filename_suffix), "w") as errfile1:
        p1 = subprocess.Popen(['ssh', LEADER_HOSTNAME, 'cd /home/debian/zelus-robot/leader/mobilebot; echo i\<3robots! | sudo -S ./mobilebot'], stdout=logfile1, stderr=errfile1, shell=False, bufsize=1, universal_newlines=True)
        #p1 = subprocess.Popen(['yes'], stdout=logfile1, stderr=errfile1)
        channels.append("LEADER_MOBILEBOT_READY")
with open("leader-kinematic{}.log".format(filename_suffix), "w") as logfile2:
    with open("leader-kinematic{}.err".format(filename_suffix), "w") as errfile2:
        p2 = subprocess.Popen(['ssh', LEADER_HOSTNAME, '"/home/debian/zelus-robot/leader/kinematic/kinematic.opt"'], stdout=logfile2, stderr=errfile2, bufsize=1, universal_newlines=True)
        #p2 = subprocess.Popen(['yes'], stdout=logfile2, stderr=errfile2)
        channels.append("LEADER_KINEMATIC_READY")

#Follower processes
with open("follower-mobilebot{}.log".format(filename_suffix), "w") as logfile3:
    with open("follower-mobilebot{}.err".format(filename_suffix), "w") as errfile3:
        p3 = subprocess.Popen(['ssh', FOLLOWER_HOSTNAME, 'cd /home/debian/zelus-robot/follower/mobilebot; echo i\<3robots! | sudo -S ./mobilebot'], stdout=logfile3, stderr=errfile3, shell=False, bufsize=1, universal_newlines=True)
        #p1 = subprocess.Popen(['yes'], stdout=logfile1, stderr=errfile1)
        channels.append("FOLLOWER_MOBILEBOT_READY")
with open("follower-kinematic{}.log".format(filename_suffix), "w") as logfile4:
    with open("follower-kinematic{}.err".format(filename_suffix), "w") as errfile4:
        p4 = subprocess.Popen(['ssh', FOLLOWER_HOSTNAME, '"/home/debian/zelus-robot/follower/kinematic/kinematic.opt"'], stdout=logfile4, stderr=errfile4, bufsize=1, universal_newlines=True)
        #p2 = subprocess.Popen(['yes'], stdout=logfile2, stderr=errfile2)
        channels.append("FOLLOWER_KINEMATIC_READY")
with open("follower-acc{}.log".format(filename_suffix), "w") as logfile5:
    with open("follower-acc{}.err".format(filename_suffix), "w") as errfile5:
        p5 = subprocess.Popen(['ssh', FOLLOWER_HOSTNAME, '"/home/debian/zelus-robot/follower/acc/acc.opt"'], stdout=logfile5, stderr=errfile5, bufsize=1, universal_newlines=True)
        #p2 = subprocess.Popen(['yes'], stdout=logfile2, stderr=errfile2)
        channels.append("FOLLOWER_ACC_READY")

print("Started processes")

lc = lcm.LCM("udpm://239.255.76.67:7667?ttl=1")

ready_signal_listener = ReadySignalListener()
for c in channels:
    ready_signal_listener.subscribe(c)
ready_signal_listener.start()
print("Waiting for threads to start up...")
print("L_MBOT\tL_KINE\tF_MBOT\tF_KINE\tF_ACC")

all_ready = False
while not all_ready:
    all_ready = True
    for c in channels:
        if ready_signal_listener.is_ready(c):
            print(LABEL_READY, end="\t")
        else:
            all_ready = False
            print(LABEL_WAIT, end="\t")
    print(end="\r")
    time.sleep(0.1)

ready_signal_listener.stop()
print()
print("All nodes ready. Press [return] to start")
input()

print("Go!")
#TODO: Send ready signal multiple times
sendReadySignal()
time.sleep(15)
cleanup()
#p1.terminate()
#p2.terminate()
#p3.terminate()
