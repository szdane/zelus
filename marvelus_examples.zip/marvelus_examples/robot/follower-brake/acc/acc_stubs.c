#include <stdio.h>
#include <string.h>
#include <caml/mlvalues.h>
#include <caml/memory.h>
#include <caml/alloc.h>
#include <caml/threads.h>
#include <pthread.h>
#include <lcm/lcm.h>
#include <time.h>
#include <unistd.h>
#include "hash_tbl.h"
#include "robot_store_t.h"
#include "ready_t.h"

#define LCM_ADDR "udpm://239.255.76.67:7667?ttl=1"
lcm_t * lcm;
pthread_t lcm_listener; 
pthread_mutex_t ready_lock;
int running = 0;
int ready = 0;

// What ACC receives on (gets the sensor info from mobilebot)
#define LISTEN_CHANNEL      	"FOLLOWER_MOBILEBOT_SENSORS"

// What ACC sends on (accel command to kinematic)
#define SEND_CHANNEL    		"FOLLOWER_ACC_ACCEL"

#define	READY_CHANNEL 			"FOLLOWER_ACC_READY"
#define SUPER_READY_CHANNEL     "SUPER_READY"

static void motor_handler(const lcm_recv_buf_t *rbuf, const char * channel, 
        const robot_store_t * msg, void * user){
    //printf("Received message on channel \"%s\":\n", channel);
    //printf("writing to table '%s' with value %f", msg->command,msg->value);
    insert_to_table(msg->command, msg->value);
}

static void ready_handler(const lcm_recv_buf_t *rbuf, const char * channel,
        const ready_t * msg, void * user){
    if (!ready){
        pthread_mutex_lock(&ready_lock);
        ready = 1;
        printf("Got the ready signal\n");
        //insert_to_table("ready", 1.0);
        pthread_mutex_unlock(&ready_lock);
    }
}

void *lcm_listen(void *param){
    ready_t_subscription_t *sub_ready = ready_t_subscribe(lcm, SUPER_READY_CHANNEL, &ready_handler, NULL);
    robot_store_t_subscription_t *sub = robot_store_t_subscribe(lcm, LISTEN_CHANNEL, &motor_handler, NULL); 
    printf("Listener Started\n");
    printf("the value of running is %d\n",running);
    while(running){
        lcm_handle(lcm); //printf ("it's now %s", "running");
    }    
    lcm_destroy(lcm);
    printf("Listener Stopped\n");
    return NULL;
}

CAMLprim value 
LCM_start(value unit){
    pthread_mutex_init(&ready_lock, NULL);
    printf("Starting LCM...\n");
    insert_to_table("ready", 0.0);
    lcm = lcm_create(LCM_ADDR);
    if(!lcm)
        return Val_int(1);
    running = 1;
    pthread_create(&lcm_listener, NULL, lcm_listen, NULL);
    int ready_to_launch = 0;
    printf("Waiting for the go signal...\n");
    while(!ready_to_launch){
        pthread_mutex_lock(&ready_lock);
        if (ready){
            ready_to_launch = 1;
        }
        else{
        }
        pthread_mutex_unlock(&ready_lock);
        
            ready_t ready_msg;
            ready_msg.utime = time(NULL) * 1000000;
            ready_t_publish(lcm, READY_CHANNEL, &ready_msg);
            usleep(50000);
    }
    return Val_int(0);
}

CAMLprim value 
LCM_stop(value unit){
    printf("Stopping Listener...\n");
    running = 0;
    //lcm_destroy(lcm);
    //printf("Listener Stopped A\n");
    return Val_unit;
}

CAMLprim value 
robot_get_cpp(value var)
{
    float a=get_value(String_val(var));
    //printf("getting '%s' from table with value %f\n", (char *)String_val(var),a);
    insert_to_table(String_val(var),0.0);//so that it does not read previous values of var
    return caml_copy_double(a);
}

CAMLprim value
robot_str_cpp(value cmd,value mag){
    //printf("robot store is called\n");
    //insert_to_table(String_val(cmd), Double_val(mag));//Store the variable to the local hash table (it can also be an update to an existing variable)
    lcm_t * lcm2 = lcm_create(LCM_ADDR);
    robot_store_t my_cmd;
    // Need to divide by 100 and convert to float since motor speeds come in as hundredths of units (and as integer arguments)
    my_cmd.command = (char *)String_val(cmd);
    my_cmd.value = Double_val(mag);
    //printf("sending '%s' to robot with value %f\n", (char *)String_val(cmd),Double_val(mag));
    robot_store_t_publish(lcm2, SEND_CHANNEL, &my_cmd); 
    lcm_destroy(lcm2);
    return Val_unit;
}
