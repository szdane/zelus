/*******************************************************************************
* mb_defs.h
*
*   defines for your bot
*   You will need to fill this in based on the data sheets, schematics, etc. 
*      and your specific configuration...
* 
*******************************************************************************/
#ifndef MB_DEFS_H
#define MB_DEFS_H

#include "mb_polarities.h"
#include <math.h>

//#define EXT_CAPE  //for use with the MOBILE ROB CAPE VERSIONS BELOW
//#define MRC_VERSION_1v3
//#define MRC_VERSION_2v1
#define BEAGLEBONE_BLUE
#define DEFAULT_PWM_FREQ        25000 // period of motor drive pwm
#define LEFT_MOTOR              1     // id of left motor
#define RIGHT_MOTOR             2     // id of right motor

#ifndef MB_POLARITIES_H

// Default to these values if you don't include a polarity file.
#define POL_LEFT_MOTOR          1
#define POL_RIGHT_MOTOR         1
#define POL_LEFT_ENCODER        1     
#define POL_RIGHT_ENCODER       -1

#endif

// TODO: Fill in physical propeties of robot
#define GEAR_RATIO              78.0  // gear ratio of motor
#define ENCODER_RES             20.0  // encoder counts per motor shaft revolution
#define WHEEL_DIAMETER          0.08254 // diameter of wheel in meters
#define WHEEL_BASE              0.1751  // wheel separation distance in meters
#define MAX_FWD_VEL             0.8   // maximum forwad speed (m/s)
#define MAX_TURN_VEL            2.5   // maximum turning speed (rad/s)
#define ENC2METERS              ((WHEEL_DIAMETER * 3.14) / (GEAR_RATIO * ENCODER_RES))

// These rates are set to defaults - can be changed
#define SAMPLE_RATE_HZ          50   // main filter and control loop speed
#define DT                      0.02  // 1/sample_rate
#define PRINTF_HZ               10    // rate of print loop
#define RC_CTL_HZ               25   // main filter and control loop speed
#define LCM_HZ                  100    // rate of LCM subscribe
#define LCM_PRIORITY            60    // priority of LCM thread (lower is less critical)
#define SETPOINT_PRIORITY       30    // priority of setpoint thread (lower is less critical)
#define CONTROLLER_PRIORITY     90    // priority of controller (lower is less critical)

#define LED_OFF                 1
#define LED_ON                  0

#endif
