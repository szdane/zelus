(* The Zelus compiler, version 2.2-dev
  (2024-06-4-20:35) *)
open Ztypes

   external robot_get: string -> float = "robot_get_cpp" 

   external robot_str_ml: string -> float -> unit = "robot_str_cpp" 

   external lcm_start: unit -> int = "LCM_start" 
 
   external lcm_stop: unit -> unit = "LCM_stop" 

  
 let () = ignore(lcm_start())
let vfi = 0.5

let dt = 0.1

let b = 0.136

let xli = 5.

let xbrake = 5.

let amax = 0.06

type _follower_control = unit

let follower_control  = 
   let follower_control_alloc _ = () in
  let follower_control_reset self  =
    ((()):unit) in 
  let follower_control_step self (((xf_99:float) ,
                                   (vf_97:float) ,
                                   (xl_100:float) , (vl_98:float)): (
                                                                    float  *
                                                                    float  *
                                                                    float  *
                                                                    float)) =
    (((if (>=) ((+.) ((+.) ((+.) ((+.) xf_99 
                                       ((/.) (( *. ) vf_97  vf_97) 
                                             (( *. ) 2.  b))) 
                                 (( *. ) ((+.) 1.  ((/.) amax  b)) 
                                         ((+.) (( *. ) (( *. ) 2.  dt)  vf_97)
                                               
                                               ((/.) (( *. ) amax 
                                                             (( *. ) 
                                                                (( *. ) 
                                                                   4.  dt) 
                                                                dt))  
                                                     2.)))) 
                           ((/.) (( *. ) vf_97  dt)  2.))  0.5) 
               ((+.) ((+.) xl_100 
                           ((/.) (( *. ) ((-.) vl_98  (( *. ) b  dt)) 
                                         ((-.) vl_98  (( *. ) b  dt))) 
                                 (( *. ) 2.  b))) 
                     ((/.) (( *. ) ((-.) vl_98  (( *. ) b  dt))  dt)  2.))
       then (~-.) b
       else amax)):float) in
  Node { alloc = follower_control_alloc; reset = follower_control_reset ;
                                         step = follower_control_step }
type _max = unit

let max  = 
   let max_alloc _ = () in
  let max_reset self  =
    ((()):unit) in 
  let max_step self ((x_101:float): float) =
    (((if (<) x_101  0. then 0. else x_101)):float) in
  Node { alloc = max_alloc; reset = max_reset ; step = max_step }
type _leader_control = unit

let leader_control  = 
   let leader_control_alloc _ = () in
  let leader_control_reset self  =
    ((()):unit) in 
  let leader_control_step self ((xl_102:float): float) =
    (((if (>=) xl_102  xbrake then (~-.) b else 0.)):float) in
  Node { alloc = leader_control_alloc; reset = leader_control_reset ;
                                       step = leader_control_step }
type ('d , 'c , 'b , 'a) _exec =
  { mutable i_155 : 'd ;
    mutable i_154 : 'c ; mutable i_120 : 'b ; mutable m_113 : 'a }

let exec  = 
  let Node { alloc = i_155_alloc; step = i_155_step ; reset = i_155_reset } = max 
   in 
  let Node { alloc = i_154_alloc; step = i_154_step ; reset = i_154_reset } = max 
   in
  let exec_alloc _ =
    ();
    { i_120 = (false:bool) ;
      m_113 = ((42. , 42. , 42. , 42. , 42. , 42.):float *
                                                   float *
                                                   float *
                                                   float * float * float);
      i_155 = i_155_alloc () (* discrete *)  ;
      i_154 = i_154_alloc () (* discrete *)  } in
  let exec_reset self  =
    ((self.i_120 <- true ; i_155_reset self.i_155  ; i_154_reset self.i_154 ):
    unit) in 
  let exec_step self () =
    (((if self.i_120 then
       self.m_113 <- (0. , vfi , amax , xli , 0. , ((~-.) b))) ;
      self.i_120 <- false ;
      (let ((x_114:float) ,
            (x_115:float) ,
            (x_116:float) , (x_117:float) , (x_118:float) , (x_119:float)) =
           self.m_113 in
       let (((xf_107:float) ,
             (vf_105:float) ,
             (af_103:float) ,
             (xl_108:float) , (vl_106:float) , (al_104:float)): (float  *
                                                                 float  *
                                                                 float  *
                                                                 float  *
                                                                 float  *
                                                                 float)) =
           (x_114 , x_115 , x_116 , x_117 , x_118 , x_119) in
       let (vl_next_109:float) = robot_get "leader_vel" in
       let (xl_next_110:float) = robot_get "leader_x" in
       let (vf_next_111:float) = robot_get "follower_vel" in
       let (xf_next_112:float) = robot_get "follower_x" in
       self.m_113 <- (xf_next_112 ,
                      vf_next_111 ,
                      (if (>=) ((+.) ((+.) ((+.) ((+.) xf_next_112 
                                                       ((/.) (( *. ) 
                                                                vf_next_111 
                                                                vf_next_111) 
                                                             (( *. ) 2.  b)))
                                                 
                                                 (( *. ) ((+.) 1. 
                                                               ((/.) amax  b))
                                                         
                                                         ((+.) (( *. ) 
                                                                  (( *. ) 
                                                                    2.  dt) 
                                                                  vf_next_111)
                                                               
                                                               ((/.) 
                                                                  (( *. ) 
                                                                    amax 
                                                                    (
                                                                    ( *. ) 
                                                                    (
                                                                    ( *. ) 
                                                                    4.  dt) 
                                                                    dt))  
                                                                  2.)))) 
                                           ((/.) (( *. ) vf_next_111  dt)  2.))
                                      0.5) 
                               ((+.) ((+.) xl_next_110 
                                           ((/.) (( *. ) ((-.) vl_next_109 
                                                               (( *. ) b  dt))
                                                         
                                                         ((-.) vl_next_109 
                                                               (( *. ) b  dt)))
                                                  (( *. ) 2.  b))) 
                                     ((/.) (( *. ) ((-.) vl_next_109 
                                                         (( *. ) b  dt))  
                                                   dt)  2.))
                       then (~-.) b
                       else amax) ,
                      xl_next_110 ,
                      vl_next_109 ,
                      (if (>=) xl_next_110  xbrake then (~-.) b else 0.)) ;
       (let _ = robot_str_ml ("accel") (af_103) in
        (xf_107 , vf_105 , af_103 , xl_108 , vl_106 , al_104)))):float *
                                                                 float *
                                                                 float *
                                                                 float *
                                                                 float *
                                                                 float) in
  Node { alloc = exec_alloc; reset = exec_reset ; step = exec_step }
type ('i , 'h , 'g , 'f , 'e , 'd , 'c , 'b , 'a) _main =
  { mutable i_157 : 'i ;
    mutable i_156 : 'h ;
    mutable major_122 : 'g ;
    mutable h_129 : 'f ;
    mutable i_127 : 'e ;
    mutable h_125 : 'd ;
    mutable result_124 : 'c ; mutable i_153 : 'b ; mutable m_146 : 'a }

let main (cstate_158:Ztypes.cstate) = 
  let Node { alloc = i_157_alloc; step = i_157_step ; reset = i_157_reset } = max 
   in 
  let Node { alloc = i_156_alloc; step = i_156_step ; reset = i_156_reset } = max 
   in
  let main_alloc _ =
    ();
    { major_122 = false ;
      h_129 = 42. ;
      i_127 = (false:bool) ;
      h_125 = (42.:float) ;
      result_124 = (():unit) ;
      i_153 = (false:bool) ;
      m_146 = ((42. , 42. , 42. , 42. , 42. , 42.):float *
                                                   float *
                                                   float *
                                                   float * float * float);
      i_157 = i_157_alloc () (* discrete *)  ;
      i_156 = i_156_alloc () (* discrete *)  } in
  let main_step self ((time_121:float) , ()) =
    ((self.major_122 <- cstate_158.major ;
      (let (result_163:unit) =
           let h_128 = ref (infinity:float) in
           (if self.i_127 then self.h_125 <- (+.) time_121  0.) ;
           (let (z_126:bool) =
                (&&) self.major_122  ((>=) time_121  self.h_125) in
            self.h_125 <- (if z_126 then (+.) self.h_125  dt else self.h_125)
            ;
            h_128 := min !h_128  self.h_125 ;
            self.h_129 <- !h_128 ;
            self.i_127 <- false ;
            (let (trigger_123:zero) = z_126 in
             (begin match trigger_123 with
                    | true ->
                        (if self.i_153 then
                         self.m_146 <- (0. ,
                                        vfi , amax , xli , 0. , ((~-.) b))) ;
                        self.i_153 <- false ;
                        (let () = () in
                         let ((x_147:float) ,
                              (x_148:float) ,
                              (x_149:float) ,
                              (x_150:float) , (x_151:float) , (x_152:float)) =
                             self.m_146 in
                         let (((xf_140:float) ,
                               (vf_138:float) ,
                               (af_136:float) ,
                               (xl_141:float) ,
                               (vl_139:float) , (al_137:float)): (float  *
                                                                  float  *
                                                                  float  *
                                                                  float  *
                                                                  float  *
                                                                  float)) =
                             (x_147 , x_148 , x_149 , x_150 , x_151 , x_152) in
                         let (vl_next_142:float) = robot_get "leader_vel" in
                         let (xl_next_143:float) = robot_get "leader_x" in
                         let (vf_next_144:float) = robot_get "follower_vel" in
                         let (xf_next_145:float) = robot_get "follower_x" in
                         self.m_146 <- (xf_next_145 ,
                                        vf_next_144 ,
                                        (if (>=) ((+.) ((+.) ((+.) ((+.) 
                                                                    xf_next_145
                                                                    
                                                                    (
                                                                    (/.) 
                                                                    (
                                                                    ( *. ) 
                                                                    vf_next_144
                                                                    
                                                                    vf_next_144)
                                                                    
                                                                    (
                                                                    ( *. ) 
                                                                    2.  b))) 
                                                                   (( *. ) 
                                                                    (
                                                                    (+.) 
                                                                    1. 
                                                                    (
                                                                    (/.) 
                                                                    amax  b))
                                                                    
                                                                    (
                                                                    (+.) 
                                                                    (
                                                                    ( *. ) 
                                                                    (
                                                                    ( *. ) 
                                                                    2.  dt) 
                                                                    vf_next_144)
                                                                    
                                                                    (
                                                                    (/.) 
                                                                    (
                                                                    ( *. ) 
                                                                    amax 
                                                                    (
                                                                    ( *. ) 
                                                                    (
                                                                    ( *. ) 
                                                                    4.  dt) 
                                                                    dt))  
                                                                    2.)))) 
                                                             ((/.) (( *. ) 
                                                                    vf_next_144
                                                                     
                                                                    dt)  
                                                                   2.))  
                                                       0.5) 
                                                 ((+.) ((+.) xl_next_143 
                                                             ((/.) (( *. ) 
                                                                    (
                                                                    (-.) 
                                                                    vl_next_142
                                                                    
                                                                    (
                                                                    ( *. ) 
                                                                    b  dt)) 
                                                                    (
                                                                    (-.) 
                                                                    vl_next_142
                                                                    
                                                                    (
                                                                    ( *. ) 
                                                                    b  dt))) 
                                                                   (( *. ) 
                                                                    2.  b))) 
                                                       ((/.) (( *. ) 
                                                                ((-.) 
                                                                   vl_next_142
                                                                   
                                                                   (( *. ) 
                                                                    b  dt)) 
                                                                dt)  
                                                             2.))
                                         then (~-.) b
                                         else amax) ,
                                        xl_next_143 ,
                                        vl_next_142 ,
                                        (if (>=) xl_next_143  xbrake
                                         then (~-.) b
                                         else 0.)) ;
                         (let _ = robot_str_ml ("accel") (af_136) in
                          let (al_131:float) = al_137 in
                          let (vl_133:float) = vl_139 in
                          let (xl_135:float) = xl_141 in
                          let (a_130:float) = af_136 in
                          let (v_132:float) = vf_138 in
                          let (x_134:float) = xf_140 in
                          let _ = print_float (Timestamp.gettimeofday ()) in
                          let _ = print_string "," in
                          let _ = print_float x_134 in
                          let _ = print_string "," in
                          let _ = print_float v_132 in
                          let _ = print_string "," in
                          let _ = print_float a_130 in
                          let _ = print_string "," in
                          let _ = print_float xl_135 in
                          let _ = print_string "," in
                          let _ = print_float vl_133 in
                          let _ = print_string "," in
                          let _ = print_float al_131 in
                          self.result_124 <- print_newline ()))
                    | _ -> self.result_124 <- ()  end) ; self.result_124)) in
       cstate_158.horizon <- min cstate_158.horizon  self.h_129 ; result_163)):
    unit) in 
  let main_reset self  =
    ((self.i_127 <- true ;
      self.i_153 <- true ; i_157_reset self.i_157  ; i_156_reset self.i_156 ):
    unit) in
  Node { alloc = main_alloc; step = main_step ; reset = main_reset }
